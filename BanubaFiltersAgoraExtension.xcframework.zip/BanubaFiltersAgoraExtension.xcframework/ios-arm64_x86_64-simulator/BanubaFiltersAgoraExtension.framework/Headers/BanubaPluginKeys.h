#import <Foundation/Foundation.h>

extern NSString * __nonnull const BNBKeyVendorName;
extern NSString * __nonnull const BNBKeyExtensionName;
extern NSString * __nonnull const BNBKeyLoadEffect;
extern NSString * __nonnull const BNBKeyUnloadEffect;
extern NSString * __nonnull const BNBKeySetBanubaLicenseToken;
extern NSString * __nonnull const BNBKeySetEffectsPath;
extern NSString * __nonnull const BNBKeyEvalJSMethod;
extern NSString * __nonnull const BNBKeyRelease;

/**
 * Deprecated, use BNBKeySetBanubaLicenseToken instead;
 */
extern NSString * __nonnull const BNBKeySetToken;
